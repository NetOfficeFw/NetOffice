﻿using System;
using System.Collections.Generic;
using System.Text;
$usingItems$
namespace $safeprojectname$
{
    public class Class1
    {
    }
}
