﻿$usingItems$
Module Module1

    Sub Main()

        ' Initialize NetOffice
        LateBindingApi.Core.Factory.Initialize()

    End Sub

End Module
