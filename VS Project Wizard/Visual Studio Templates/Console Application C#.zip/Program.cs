﻿using System;
using System.Collections.Generic;
using System.Text;
$usingItems$
namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
