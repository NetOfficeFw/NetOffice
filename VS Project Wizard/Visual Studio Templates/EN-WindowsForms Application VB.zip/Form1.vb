﻿$usingItems$
Public Class Form1

    Public Sub New()

        InitializeComponent()

        ' Initialize NetOffice
        ' LateBindingApi.Core.Factory.Initialize()

    End Sub

End Class
